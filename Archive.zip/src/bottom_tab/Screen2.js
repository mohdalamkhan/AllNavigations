import { View, Text } from 'react-native'
import React from 'react'

const Screen2 = () => {
  return (
    <View style={{flex:1,backgroundColor:'pink'}}>
      <Text>Screen2</Text>
    </View>
  )
}

export default Screen2