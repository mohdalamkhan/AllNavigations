import { View, Text } from 'react-native'
import React from 'react'

const Screen1 = () => {
  return (
    <View style={{flex:1,backgroundColor:'skyblue'}}>
      <Text>Screen1</Text>
    </View>
  )
}

export default Screen1