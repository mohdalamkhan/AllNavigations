import { View, Text } from 'react-native'
import React from 'react'

const Screen3 = () => {
  return (
    <View style={{flex:1,backgroundColor:'yellow'}}>
      <Text>Screen3</Text>
    </View>
  )
}

export default Screen3